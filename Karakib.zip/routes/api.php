<?php

use App\Http\Controllers\Api\LoginController;
use App\Http\Controllers\Api\LogoutController;
use App\Http\Controllers\Api\ProfileController;
use App\Http\Controllers\Api\RegisterController;
use App\Http\Controllers\Api\UsersController;
use App\Http\Controllers\Api\WasteItemController;
use App\Http\Controllers\Api\WasteTypeController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;

// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');

Route::options('/{any}', function (Request $request) {
    return response('', 204)
        ->header('Access-Control-Allow-Origin', 'https://karakib.netlify.app')
        ->header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        ->header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
})->where('any', '.*');

Route::post('/register', [RegisterController::class, 'register']);
Route::post('/login', [LoginController::class, 'login']);

Route::get('/storage-link', function () {
    if (request()->input('secret') !== 'beshoy') {
        return response()->json(['error' => 'Unauthorized'], 403);
    }

    try {
        Artisan::call('storage:link');
        return response()->json(['message' => 'Storage link created successfully']);
    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()], 500);
    }
});

Route::get('/migrate', function () {
    if (request()->input('secret') !== 'beshoy') {
        return response()->json(['error' => 'Unauthorized'], 403);
    }

    try {
        Artisan::call('migrate');
        Artisan::call('cache:clear');
        Artisan::call('config:clear');
        Artisan::call('view:clear');
        Artisan::call('route:clear');
        Artisan::call('event:clear');
        Artisan::call('optimize:clear');
        Artisan::call('queue:flush');

        Artisan::call('config:cache');
        Artisan::call('route:cache');
        Artisan::call('view:cache');

        Artisan::call('optimize');
        return response()->json(['message' => 'migrated successfully']);
    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()], 500);
    }
});

Route::get('/admin-statistics', [WasteTypeController::class, 'index']);


Route::get('/waste-types', [WasteTypeController::class, 'index']);
Route::get('/waste-types/{id}', [WasteTypeController::class, 'show']);

Route::get('/waste-items', [WasteItemController::class, 'index']);
Route::get('/waste-items/{id}', [WasteItemController::class, 'show']);



Route::middleware('auth:sanctum')->group(function () {
    Route::post('/registerAdmin', [RegisterController::class, 'register'])->middleware('admin');
    Route::post('/logout', [LogoutController::class, 'logout']);
    Route::get('/user', fn(Request $request) => $request->user());

    Route::put('/profile', [ProfileController::class, 'update']);
    Route::delete('/profile/destroy', [ProfileController::class, 'destroy']);

    // Your protected routes here
    Route::middleware('admin')->group(function () {
        Route::post('/waste-types', [WasteTypeController::class, 'store']);
        Route::put('/waste-types/{wasteType}', [WasteTypeController::class, 'update']);
        Route::delete('/waste-types/{wasteType}', [WasteTypeController::class, 'destroy']);

        Route::post('/waste-items', [WasteItemController::class, 'store']);
        Route::put('/waste-items/{id}', [WasteItemController::class, 'update']);
        Route::delete('/waste-items/{id}', [WasteItemController::class, 'destroy']);

        Route::get('/users', [UsersController::class, 'index']);
        Route::put('/users/{user}', [UsersController::class, 'update']);
        Route::delete('/users/{user}', [UsersController::class, 'destroy']);
    });
});
