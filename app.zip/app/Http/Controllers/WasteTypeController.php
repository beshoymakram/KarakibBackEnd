<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WasteTypeController extends Controller
{
    //
}
